-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 05 Apr 2020 pada 08.52
-- Versi server: 10.1.35-MariaDB
-- Versi PHP: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pembayaran`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE `login` (
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('user', '123');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `id` int(30) NOT NULL,
  `nama` varchar(35) NOT NULL,
  `harga` int(50) NOT NULL,
  `beli` int(30) NOT NULL,
  `total` int(30) NOT NULL,
  `bayar` int(30) NOT NULL,
  `kembalian` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `transaksi`
--

INSERT INTO `transaksi` (`id`, `nama`, `harga`, `beli`, `total`, `bayar`, `kembalian`) VALUES
(2, 'Nescafe Espresso', 18000, 1, 18000, 20000, 'Rp.2000'),
(3, 'Delfi Almon Choho', 15000, 1, 15000, 20000, 'Rp.5000'),
(4, 'Orange Squash', 11000, 3, 33000, 50000, 'Rp.17000'),
(5, 'Delfi Almon Choho', 15000, 5, 75000, 100000, 'Rp.25000'),
(6, 'Orange Squash', 11000, 3, 33000, 50000, 'Rp.17000'),
(7, 'Orange Squash', 11000, 2, 22000, 22000, 'Rp.0'),
(8, 'Orange Squash', 11000, 2, 22000, 50000, 'Rp.28000'),
(9, 'Delfi Almon Choho', 15000, 2, 30000, 50000, 'Rp.20000'),
(10, 'Orange Squash', 11000, 1, 11000, 15000, 'Rp.4000'),
(11, 'Orange Squash', 11000, 1, 11000, 15000, '4000'),
(12, 'Delfi Almond Chocho', 15000, 3, 45000, 50000, 'Rp.5000'),
(13, 'Nescafe Espresso', 16000, 3, 48000, 50000, 'Rp.2000'),
(14, 'Orange Squash', 11000, 1, 11000, 15000, 'Rp.4000'),
(15, 'Delfi Almond Chocho', 15000, 1, 15000, 15000, 'Rp.0'),
(16, 'Orange Squash', 11000, 1, 11000, 15000, 'Rp.4000'),
(17, 'Delfi Almond Chocho', 15000, 2, 30000, 50000, 'Rp.20000'),
(18, 'Nescafe Espresso', 16000, 1, 16000, 20000, 'Rp.4000'),
(19, 'Delfi Almond Chocho', 15000, 2, 30000, 50000, 'Rp.20000'),
(20, 'Delfi Almond Chocho', 15000, 1, 15000, 15000, 'Rp.0'),
(21, 'Delfi Almond Chocho', 15000, 2, 30000, 30000, 'Rp.0');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
